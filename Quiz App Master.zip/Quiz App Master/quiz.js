const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const restartButton = document.getElementById("restart-btn");
const addQuestionButton = document.getElementById("add-question-btn");

let questions = JSON.parse(localStorage.getItem("quizQuestions")) || [
    {
        question: "What is the capital of France?",
        answers: [
            { text: "Paris", correct: true },
            { text: "London", correct: false },
            { text: "Berlin", correct: false },
            { text: "Madrid", correct: false }
        ]
    }
];

let currentQuestionIndex = 0;
let score = 0;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.style.display = "none";
    restartButton.style.display = "none";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    questionElement.innerText = currentQuestion.question;
    currentQuestion.answers.forEach((answer, index) => {
        const button = document.createElement("button");
        button.innerText = answer.text;
        button.classList.add("btn");
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
        answerButtons.appendChild(button);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.dataset.correct;
    if (correct) {
        score++;
        selectedButton.style.background = "green";
    } else {
        selectedButton.style.background = "red";
    }
    Array.from(answerButtons.children).forEach(button => {
        button.disabled = true;
        if (button.dataset.correct) {
            button.style.background = "green";
        }
    });
    nextButton.style.display = "block";
}

nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        questionElement.innerText = `You scored ${score} out of ${questions.length}!`;
        answerButtons.innerHTML = "";
        nextButton.style.display = "none";
        restartButton.style.display = "block";
    }
});

restartButton.addEventListener("click", startQuiz);

// Function to Add a New Question Dynamically
addQuestionButton.addEventListener("click", () => {
    const newQuestionText = document.getElementById("new-question").value;
    const option1 = document.getElementById("option1").value;
    const option2 = document.getElementById("option2").value;
    const option3 = document.getElementById("option3").value;
    const option4 = document.getElementById("option4").value;
    const correctIndex = document.getElementById("correct-answer").value;

    if (newQuestionText && option1 && option2 && option3 && option4) {
        const newQuestion = {
            question: newQuestionText,
            answers: [
                { text: option1, correct: correctIndex == 0 },
                { text: option2, correct: correctIndex == 1 },
                { text: option3, correct: correctIndex == 2 },
                { text: option4, correct: correctIndex == 3 }
            ]
        };

        questions.push(newQuestion);
        localStorage.setItem("quizQuestions", JSON.stringify(questions));
        alert("Question added successfully!");
        document.getElementById("new-question").value = "";
        document.getElementById("option1").value = "";
        document.getElementById("option2").value = "";
        document.getElementById("option3").value = "";
        document.getElementById("option4").value = "";
    } else {
        alert("Please fill all fields!");
    }
});

startQuiz();
